namespace Task_Tracker
{
    partial class Client
    {
    }

    partial class Project
    {
    }

    partial class Task
    {
    }

    partial class DeveloperIterationTask
    {
    }

    partial class Iteration
    {
    }

    partial class IterationTask
    {
    }

    partial class Developer
    {
    }
}